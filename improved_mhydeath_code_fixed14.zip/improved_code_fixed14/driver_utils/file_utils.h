#pragma once

#include <string>
#include <string_view>
#include <Windows.h>

namespace file_utils {
    /**
     * @brief Creates a file from a memory buffer
     * 
     * @param file_path Path where the file will be created
     * @param buffer Pointer to the data buffer
     * @param size Size of the buffer in bytes
     * @return true if file was created successfully
     * @return false if an error occurred
     */
    bool create_file_from_buffer(const char* file_path, const void* buffer, size_t size);
    
    /**
     * @brief Gets the last Windows error as a string
     * 
     * @return std::string Error message
     */
    std::string get_last_error_as_string();
}
