#include "service_utils.h"
#include <iostream>

namespace service_utils {

/**
 * @brief Open the service control manager
 * 
 * @return SC_HANDLE Handle to the service control manager, or nullptr on failure
 */
SC_HANDLE open_sc_manager() {
    SC_HANDLE sc_manager_handle = OpenSCManager(
        nullptr,                    // local computer
        nullptr,                    // ServicesActive database
        SC_MANAGER_CREATE_SERVICE   // need create service rights
    );
    
    if (!sc_manager_handle) {
        std::cerr << "[!] Failed to open service control manager: " 
                  << GetLastError() << std::endl;
    }
    
    return sc_manager_handle;
}

/**
 * @brief Create a new service
 * 
 * @param driver_path Path to the driver file
 * @return SC_HANDLE Handle to the created service, or nullptr on failure
 */
SC_HANDLE create_service(const wchar_t* driver_path) {
    // Open service control manager
    SC_HANDLE sc_manager = open_sc_manager();
    
    if (!sc_manager) {
        return nullptr;
    }
    
    // Create the service
    SC_HANDLE service_handle = CreateServiceW(
        sc_manager,                     // SCM database
        L"mhyprotect",                  // service name
        L"mhyprotect",                  // display name
        SERVICE_START | SERVICE_STOP | DELETE, // desired access
        SERVICE_KERNEL_DRIVER,          // service type
        SERVICE_DEMAND_START,           // start type
        SERVICE_ERROR_IGNORE,           // error control type
        driver_path,                    // path to service's binary
        nullptr,                        // no load ordering group
        nullptr,                        // no tag identifier
        nullptr,                        // no dependencies
        nullptr,                        // LocalSystem account
        nullptr                         // no password
    );
    
    if (!service_handle) {
        DWORD error = GetLastError();
        if (error == ERROR_SERVICE_EXISTS) {
            // Service already exists, try to open it
            service_handle = OpenServiceW(
                sc_manager,
                L"mhyprotect",
                SERVICE_START | SERVICE_STOP | DELETE
            );
            
            if (!service_handle) {
                std::cerr << "[!] Failed to open existing service: " 
                          << GetLastError() << std::endl;
                CloseServiceHandle(sc_manager);
                return nullptr;
            }
        } else {
            std::cerr << "[!] Failed to create service: " << error << std::endl;
            CloseServiceHandle(sc_manager);
            return nullptr;
        }
    }
    
    // Close the service control manager handle
    CloseServiceHandle(sc_manager);
    
    return service_handle;
}

/**
 * @brief Start a service
 * 
 * @param service_handle Handle to the service
 * @return true if service was started successfully
 * @return false if service failed to start
 */
bool start_service(SC_HANDLE service_handle) {
    if (!service_handle) {
        std::cerr << "[!] Invalid service handle" << std::endl;
        return false;
    }
    
    if (!StartServiceW(service_handle, 0, nullptr)) {
        DWORD error = GetLastError();
        if (error == ERROR_SERVICE_ALREADY_RUNNING) {
            // Service is already running, which is fine
            return true;
        }
        
        std::cerr << "[!] Failed to start service: " << error << std::endl;
        return false;
    }
    
    return true;
}

/**
 * @brief Stop a service
 * 
 * @param service_handle Handle to the service
 * @return true if service was stopped successfully
 * @return false if service failed to stop
 */
bool stop_service(SC_HANDLE service_handle) {
    if (!service_handle) {
        std::cerr << "[!] Invalid service handle" << std::endl;
        return false;
    }
    
    SERVICE_STATUS service_status;
    if (!ControlService(service_handle, SERVICE_CONTROL_STOP, &service_status)) {
        DWORD error = GetLastError();
        if (error == ERROR_SERVICE_NOT_ACTIVE) {
            // Service is already stopped, which is fine
            return true;
        }
        
        std::cerr << "[!] Failed to stop service: " << error << std::endl;
        return false;
    }
    
    return true;
}

/**
 * @brief Delete a service
 * 
 * @param service_handle Handle to the service
 * @return true if service was deleted successfully
 * @return false if service failed to delete
 */
bool delete_service(SC_HANDLE service_handle) {
    if (!service_handle) {
        std::cerr << "[!] Invalid service handle" << std::endl;
        return false;
    }
    
    if (!DeleteService(service_handle)) {
        DWORD error = GetLastError();
        if (error == ERROR_SERVICE_MARKED_FOR_DELETE) {
            // Service is already marked for deletion, which is fine
            return true;
        }
        
        std::cerr << "[!] Failed to delete service: " << error << std::endl;
        return false;
    }
    
    return true;
}

/**
 * @brief Delete a service by name if it exists
 * 
 * @param service_name Name of the service to delete
 * @return true if service was deleted or didn't exist
 * @return false if service deletion failed
 */
bool delete_service_with_check(const wchar_t* service_name) {
    // Open service control manager
    SC_HANDLE sc_manager = open_sc_manager();
    
    if (!sc_manager) {
        return false;
    }
    
    // Try to open the service
    SC_HANDLE service = OpenServiceW(
        sc_manager,
        service_name,
        DELETE
    );
    
    if (!service) {
        DWORD error = GetLastError();
        CloseServiceHandle(sc_manager);
        
        if (error == ERROR_SERVICE_DOES_NOT_EXIST) {
            // Service doesn't exist, which is fine
            return true;
        }
        
        std::cerr << "[!] Failed to open service for deletion: " << error << std::endl;
        return false;
    }
    
    // Delete the service
    bool result = delete_service(service);
    
    // Clean up handles
    CloseServiceHandle(service);
    CloseServiceHandle(sc_manager);
    
    return result;
}

} // namespace service_utils
