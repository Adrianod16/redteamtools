#pragma once

#include <string>
#include <vector>
#include <Windows.h>
#include <TlHelp32.h>

namespace win_utils {
    /**
     * @brief Find a process ID by its name
     * 
     * @param process_name Name of the process to find
     * @return DWORD Process ID if found, 0 if not found
     */
    DWORD find_process_id(const wchar_t* process_name);
    
    /**
     * @brief Check if a handle is valid
     * 
     * @param handle Handle to check
     * @return true if handle is valid
     * @return false if handle is invalid
     */
    bool is_handle_valid(HANDLE handle);
    
    /**
     * @brief Get the last Windows error as a string
     * 
     * @return std::string Error message
     */
    std::string get_last_error_as_string();
    
    /**
     * @brief Create a safe handle and return it
     * 
     * @param handle Handle to use
     * @return HANDLE The handle
     */
    HANDLE create_safe_handle(HANDLE handle);
}
