#pragma once

#include <string>
#include <Windows.h>

namespace service_utils {
    /**
     * @brief Open the service control manager
     * 
     * @return SC_HANDLE Handle to the service control manager, or nullptr on failure
     */
    SC_HANDLE open_sc_manager();
    
    /**
     * @brief Create a new service
     * 
     * @param driver_path Path to the driver file
     * @return SC_HANDLE Handle to the created service, or nullptr on failure
     */
    SC_HANDLE create_service(const wchar_t* driver_path);
    
    /**
     * @brief Start a service
     * 
     * @param service_handle Handle to the service
     * @return true if service was started successfully
     * @return false if service failed to start
     */
    bool start_service(SC_HANDLE service_handle);
    
    /**
     * @brief Stop a service
     * 
     * @param service_handle Handle to the service
     * @return true if service was stopped successfully
     * @return false if service failed to stop
     */
    bool stop_service(SC_HANDLE service_handle);
    
    /**
     * @brief Delete a service
     * 
     * @param service_handle Handle to the service
     * @return true if service was deleted successfully
     * @return false if service failed to delete
     */
    bool delete_service(SC_HANDLE service_handle);
    
    /**
     * @brief Delete a service by name if it exists
     * 
     * @param service_name Name of the service to delete
     * @return true if service was deleted or didn't exist
     * @return false if service deletion failed
     */
    bool delete_service_with_check(const wchar_t* service_name);
}
