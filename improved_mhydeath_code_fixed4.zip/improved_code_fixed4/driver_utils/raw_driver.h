#pragma once

// Include raw driver data
namespace resource {
    // This would normally contain the actual driver binary data
    // For this example, we're using a placeholder
    extern const unsigned char raw_driver[1024];
}
