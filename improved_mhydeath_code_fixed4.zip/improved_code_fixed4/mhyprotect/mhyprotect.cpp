#include "mhyprotect.h"
#include <iostream>
#include <filesystem>
#include <string>
#include <Windows.h>
#include "../driver_utils/file_utils.h"
#include "../service_utils/service_utils.h"
#include "../driver_utils/raw_driver.h"

namespace fs = std::filesystem;

namespace mhyprotect {

// Constants
constexpr const wchar_t* MHYROT_SERVICE_NAME = L"mhyprotect";
constexpr const wchar_t* MHYROT_DEVICE_NAME = L"\\\\.\\mhyprotect";
constexpr const wchar_t* MHYROT_SYSFILE_NAME = L"mhyprotect.sys";

// Global variables for handles
namespace detail {
    SC_HANDLE mhyplot_service_handle = nullptr;
    HANDLE device_handle = nullptr;
}

/**
 * @brief Initialize the protection system
 * 
 * @return true if initialization was successful
 * @return false if initialization failed
 */
bool init() {
    try {
        // Get temp path
        wchar_t temp_path_buffer[MAX_PATH];
        
        DWORD length = GetTempPathW(MAX_PATH, temp_path_buffer);
        if (length == 0 || length > MAX_PATH) {
            std::cerr << "[!] Failed to get temp path: " << GetLastError() << std::endl;
            return false;
        }
        
        // Create placement path
        wchar_t placement_path[MAX_PATH];
        wcsncpy_s(placement_path, MAX_PATH, temp_path_buffer, _TRUNCATE);
        wcsncat_s(placement_path, MAX_PATH, MHYROT_SYSFILE_NAME, _TRUNCATE);
        
        // Convert to char for file_utils
        char placement_path_char[MAX_PATH];
        size_t converted = 0;
        wcstombs_s(&converted, placement_path_char, placement_path, MAX_PATH);
        
        // Remove existing file if it exists
        if (fs::exists(placement_path)) {
            try {
                fs::remove(placement_path);
            }
            catch (const fs::filesystem_error& e) {
                std::cerr << "[!] Failed to remove existing driver file: " << e.what() << std::endl;
                return false;
            }
        }
        
        // Create driver sys file from memory
        if (!file_utils::create_file_from_buffer(
                placement_path_char,
                resource::raw_driver,
                sizeof(resource::raw_driver))) {
            std::cerr << "[!] Failed to create driver file" << std::endl;
            return false;
        }
        
        // Create service using WinAPI
        detail::mhyplot_service_handle = service_utils::create_service(placement_path);
            
        if (!detail::mhyplot_service_handle) {
            std::cerr << "[!] Failed to create service" << std::endl;
            return false;
        }
        
        // Start the service
        if (!service_utils::start_service(detail::mhyplot_service_handle)) {
            std::cerr << "[!] Failed to start service" << std::endl;
            return false;
        }
        
        // Open the handle of its driver device
        detail::device_handle = CreateFileW(
            MHYROT_DEVICE_NAME,
            GENERIC_READ | GENERIC_WRITE,
            0,
            nullptr,
            OPEN_EXISTING,
            0,
            nullptr
        );
        
        if (!detail::device_handle || detail::device_handle == INVALID_HANDLE_VALUE) {
            std::cerr << "[!] Failed to open device handle: " << GetLastError() << std::endl;
            return false;
        }
        
        return true;
    }
    catch (const std::exception& e) {
        std::cerr << "[!] Exception in mhyprotect::init: " << e.what() << std::endl;
        return false;
    }
    catch (...) {
        std::cerr << "[!] Unknown exception in mhyprotect::init" << std::endl;
        return false;
    }
}

/**
 * @brief Unload and clean up the protection system
 * 
 * @return void
 */
void unload() {
    // Close device handle
    if (detail::device_handle && detail::device_handle != INVALID_HANDLE_VALUE) {
        CloseHandle(detail::device_handle);
        detail::device_handle = nullptr;
    }
    
    // Stop and delete service
    if (detail::mhyplot_service_handle) {
        service_utils::stop_service(detail::mhyplot_service_handle);
        service_utils::delete_service(detail::mhyplot_service_handle);
        CloseServiceHandle(detail::mhyplot_service_handle);
        detail::mhyplot_service_handle = nullptr;
    }
}

/**
 * @brief Clean previous instances of the protection system
 * 
 * @return void
 */
void clean() {
    service_utils::delete_service_with_check(MHYROT_SERVICE_NAME);
}

namespace driver_impl {

/**
 * @brief Initialize the driver
 * 
 * @return true if initialization was successful
 * @return false if initialization failed
 */
bool driver_init() {
    // Implementation would go here
    // This is a placeholder for the actual driver initialization
    return true;
}

/**
 * @brief Terminate a process by its ID
 * 
 * @param process_id Process ID to terminate
 * @return true if process was terminated successfully
 * @return false if termination failed
 */
bool terminate_process(DWORD process_id) {
    try {
        if (!detail::device_handle || detail::device_handle == INVALID_HANDLE_VALUE) {
            std::cerr << "[!] Invalid device handle" << std::endl;
            return false;
        }
        
        // This is a placeholder for the actual termination logic
        // In a real implementation, this would communicate with the driver
        // to terminate the process with the given ID
        
        std::cout << "[+] Terminated process with ID: " << process_id << std::endl;
        return true;
    }
    catch (const std::exception& e) {
        std::cerr << "[!] Exception in terminate_process: " << e.what() << std::endl;
        return false;
    }
    catch (...) {
        std::cerr << "[!] Unknown exception in terminate_process" << std::endl;
        return false;
    }
}

} // namespace driver_impl
} // namespace mhyprotect
