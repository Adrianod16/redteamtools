#pragma once

// Include raw driver data
namespace resource {
    // This would normally contain the actual driver binary data
    // For this example, we're using a placeholder
    extern unsigned char* raw_driver;
    extern unsigned char raw_driver_data[1024]; // Make the actual data array accessible
}
