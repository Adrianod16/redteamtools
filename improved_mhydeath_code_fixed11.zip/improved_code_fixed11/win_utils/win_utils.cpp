#include "win_utils.h"
#include <iostream>
#include <algorithm>
#include <cctype> // For towlower

namespace win_utils {

/**
 * @brief Find a process ID by its name
 * 
 * @param process_name Name of the process to find
 * @return DWORD Process ID if found, 0 if not found
 */
DWORD find_process_id(const wchar_t* process_name) {
    // Create snapshot of processes
    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    
    if (!hSnap || hSnap == INVALID_HANDLE_VALUE) {
        std::cerr << "[!] Failed to create process snapshot: " 
                  << get_last_error_as_string() << std::endl;
        return 0;
    }
    
    PROCESSENTRY32 processentry = { sizeof(PROCESSENTRY32) };
    
    // Get first process
    if (!Process32First(hSnap, &processentry)) {
        std::cerr << "[!] Failed to get first process: " 
                  << get_last_error_as_string() << std::endl;
        CloseHandle(hSnap);
        return 0;
    }
    
    // Convert process_name to lowercase for case-insensitive comparison
    wchar_t process_name_lower[MAX_PATH];
    wcsncpy_s(process_name_lower, MAX_PATH, process_name, _TRUNCATE);
    for (int i = 0; process_name_lower[i]; i++) {
        process_name_lower[i] = towlower(process_name_lower[i]);
    }
    
    DWORD result = 0;
    
    // Iterate through processes
    do {
        // Convert CHAR to wchar_t for proper comparison
        wchar_t current_name[MAX_PATH];
        size_t convertedChars = 0;
        mbstowcs_s(&convertedChars, current_name, processentry.szExeFile, MAX_PATH);
        
        // Convert to lowercase
        for (int i = 0; current_name[i]; i++) {
            current_name[i] = towlower(current_name[i]);
        }
        
        // Compare process names
        if (wcscmp(current_name, process_name_lower) == 0) {
            result = processentry.th32ProcessID;
            break;
        }
    } while (Process32Next(hSnap, &processentry));
    
    // Clean up
    CloseHandle(hSnap);
    
    // Return process ID or 0 if not found
    return result;
}

/**
 * @brief Check if a handle is valid
 * 
 * @param handle Handle to check
 * @return true if handle is valid
 * @return false if handle is invalid
 */
bool is_handle_valid(HANDLE handle) {
    return (handle != nullptr && handle != INVALID_HANDLE_VALUE);
}

/**
 * @brief Get the last Windows error as a string
 * 
 * @return std::string Error message
 */
std::string get_last_error_as_string() {
    DWORD error_code = GetLastError();
    if (error_code == 0) {
        return "No error";
    }
    
    LPSTR message_buffer = nullptr;
    size_t size = FormatMessageA(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
        nullptr,
        error_code,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        reinterpret_cast<LPSTR>(&message_buffer),
        0,
        nullptr
    );
    
    std::string error_message;
    if (size > 0 && message_buffer != nullptr) {
        error_message = std::string(message_buffer, size);
        
        // Remove trailing newlines and carriage returns
        while (!error_message.empty() && 
               (error_message.back() == '\n' || error_message.back() == '\r')) {
            error_message.pop_back();
        }
        
        // Free the buffer
        LocalFree(message_buffer);
    } else {
        error_message = "Unknown error";
    }
    
    return "(" + std::to_string(error_code) + ") " + error_message;
}

/**
 * @brief Create a safe handle and return it
 * 
 * @param handle Handle to use
 * @return HANDLE The handle
 */
HANDLE create_safe_handle(HANDLE handle) {
    return handle;
}

} // namespace win_utils
