#include "process_killer.h"
#include <algorithm>
#include <iostream>
#include <TlHelp32.h>
#include <cctype> // For towlower
#include "../mhyprotect/mhyprotect.h"

namespace process_killer {

// List of target process names to terminate
const wchar_t* target_processes[] = {
    L"MhyRunner.exe",
    L"MhyProtect.exe",
    L"MhyService.exe",
    nullptr // Null terminator
};

/**
 * @brief Converts a wide string to lowercase for case-insensitive comparison
 * 
 * @param str Input wide string
 * @return wchar_t* Lowercase version of the input string (must be freed by caller)
 */
wchar_t* to_lowercase(const wchar_t* str) {
    if (!str) return nullptr;
    
    size_t len = wcslen(str);
    wchar_t* result = new wchar_t[len + 1];
    
    for (size_t i = 0; i < len; i++) {
        result[i] = towlower(str[i]);
    }
    result[len] = L'\0';
    
    return result;
}

/**
 * @brief Checks if a process name is in the target list
 * 
 * @param name Process name to check
 * @return true if the process is a target
 * @return false if the process is not a target
 */
bool is_a_target(const wchar_t* name) {
    if (!name) return false;
    
    wchar_t* name_lower = to_lowercase(name);
    bool result = false;
    
    for (int i = 0; target_processes[i] != nullptr; i++) {
        wchar_t* target_lower = to_lowercase(target_processes[i]);
        
        if (wcscmp(target_lower, name_lower) == 0) {
            result = true;
        }
        
        delete[] target_lower;
        if (result) break;
    }
    
    delete[] name_lower;
    return result;
}

/**
 * @brief Terminates all processes that match target criteria
 * 
 * @return void
 */
void kill_target_processes() {
    // Create snapshot of processes
    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    
    if (!hSnap || hSnap == INVALID_HANDLE_VALUE) {
        std::cerr << "[!] Failed to create process snapshot: " 
                  << GetLastError() << std::endl;
        return;
    }
    
    PROCESSENTRY32 processEntry = { sizeof(PROCESSENTRY32) };
    
    // Get first process
    if (!Process32First(hSnap, &processEntry)) {
        std::cerr << "[!] Failed to get first process: " 
                  << GetLastError() << std::endl;
        CloseHandle(hSnap);
        return;
    }
    
    // Iterate through all processes
    do {
        // Convert CHAR to wchar_t for proper comparison
        wchar_t wideExeName[MAX_PATH];
        size_t convertedChars = 0;
        mbstowcs_s(&convertedChars, wideExeName, processEntry.szExeFile, MAX_PATH);
        
        // Check if this process is a target
        if (is_a_target(wideExeName)) {
            std::wcout << L"[*] Found target process: " << wideExeName 
                      << L" (PID: " << processEntry.th32ProcessID << L")" << std::endl;
            
            // Attempt to terminate the process
            if (mhyprotect::driver_impl::terminate_process(processEntry.th32ProcessID)) {
                std::wcout << L"[+] Successfully terminated process: " 
                          << wideExeName << std::endl;
            } else {
                std::wcerr << L"[!] Failed to terminate process: " 
                          << wideExeName << std::endl;
            }
        }
    } while (Process32Next(hSnap, &processEntry));
    
    // Clean up
    CloseHandle(hSnap);
}

/**
 * @brief Gets the list of target process names
 * 
 * @return const wchar_t** Array of target process names (null-terminated)
 */
const wchar_t** get_target_list() {
    return const_cast<const wchar_t**>(target_processes);
}

} // namespace process_killer
