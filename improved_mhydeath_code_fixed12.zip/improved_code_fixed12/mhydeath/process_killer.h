#pragma once

#include <string>
#include <vector>
#include <Windows.h>

namespace process_killer {
    /**
     * @brief Converts a wide string to lowercase for case-insensitive comparison
     * 
     * @param str Input wide string
     * @return wchar_t* Lowercase version of the input string (must be freed by caller)
     */
    wchar_t* to_lowercase(const wchar_t* str);
    
    /**
     * @brief Checks if a process name is in the target list
     * 
     * @param name Process name to check
     * @return true if the process is a target
     * @return false if the process is not a target
     */
    bool is_a_target(const wchar_t* name);
    
    /**
     * @brief Terminates all processes that match target criteria
     * 
     * @return void
     */
    void kill_target_processes();
    
    /**
     * @brief Gets the list of target process names
     * 
     * @return const wchar_t** Array of target process names (null-terminated)
     */
    const wchar_t** get_target_list();
}
