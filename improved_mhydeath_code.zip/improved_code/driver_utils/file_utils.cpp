#include "file_utils.h"
#include <fstream>
#include <iostream>
#include <system_error>

namespace file_utils {

/**
 * @brief Creates a file from a memory buffer
 * 
 * @param file_path Path where the file will be created
 * @param buffer Pointer to the data buffer
 * @param size Size of the buffer in bytes
 * @return true if file was created successfully
 * @return false if an error occurred
 */
bool create_file_from_buffer(const std::string_view file_path, const void* buffer, size_t size) {
    try {
        // Open file with exception handling
        std::ofstream stream(std::string(file_path), std::ios::binary | std::ios::out);
        if (!stream) {
            std::cerr << "[!] Failed to open file: " << file_path << " - " 
                      << get_last_error_as_string() << std::endl;
            return false;
        }
        
        // Write buffer to file
        stream.write(static_cast<const char*>(buffer), size);
        
        // Check for write errors
        if (!stream) {
            std::cerr << "[!] Failed to write to file: " << file_path << std::endl;
            stream.close();
            return false;
        }
        
        // Close file (automatically done by destructor, but explicit for clarity)
        stream.close();
        return true;
    }
    catch (const std::exception& e) {
        std::cerr << "[!] Exception while creating file: " << e.what() << std::endl;
        return false;
    }
}

/**
 * @brief Gets the last Windows error as a string
 * 
 * @return std::string Error message
 */
std::string get_last_error_as_string() {
    DWORD error_code = GetLastError();
    if (error_code == 0) {
        return "No error";
    }
    
    LPSTR message_buffer = nullptr;
    size_t size = FormatMessageA(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
        nullptr,
        error_code,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        reinterpret_cast<LPSTR>(&message_buffer),
        0,
        nullptr
    );
    
    // Create a unique_ptr with custom deleter for automatic cleanup
    std::unique_ptr<char, std::function<void(char*)>> message(
        message_buffer, 
        [](char* p) { if (p) LocalFree(p); }
    );
    
    if (size == 0) {
        return "Unknown error";
    }
    
    std::string error_message(message.get(), size);
    
    // Remove trailing newlines and carriage returns
    while (!error_message.empty() && 
           (error_message.back() == '\n' || error_message.back() == '\r')) {
        error_message.pop_back();
    }
    
    return "(" + std::to_string(error_code) + ") " + error_message;
}

} // namespace file_utils
