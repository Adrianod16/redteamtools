#include "win_utils.h"
#include <iostream>
#include <memory>
#include <functional>
#include <algorithm>

namespace win_utils {

/**
 * @brief Find a process ID by its name
 * 
 * @param process_name Name of the process to find
 * @return DWORD Process ID if found, 0 if not found
 */
DWORD find_process_id(const std::wstring& process_name) {
    // Create snapshot of processes with RAII
    auto snapshot = create_safe_handle(
        CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0),
        [](HANDLE h) { if (h && h != INVALID_HANDLE_VALUE) CloseHandle(h); }
    );
    
    if (!snapshot || snapshot.get() == INVALID_HANDLE_VALUE) {
        std::cerr << "[!] Failed to create process snapshot: " 
                  << get_last_error_as_string() << std::endl;
        return 0;
    }
    
    PROCESSENTRY32 processentry = { sizeof(PROCESSENTRY32) };
    
    // Get first process
    if (!Process32First(snapshot.get(), &processentry)) {
        std::cerr << "[!] Failed to get first process: " 
                  << get_last_error_as_string() << std::endl;
        return 0;
    }
    
    // Convert process_name to lowercase for case-insensitive comparison
    std::wstring process_name_lower = process_name;
    std::transform(process_name_lower.begin(), process_name_lower.end(), 
                  process_name_lower.begin(), ::towlower);
    
    // Iterate through processes
    do {
        // Convert current process name to lowercase
        std::wstring current_name = processentry.szExeFile;
        std::transform(current_name.begin(), current_name.end(), 
                      current_name.begin(), ::towlower);
        
        // Compare process names
        if (current_name == process_name_lower) {
            return processentry.th32ProcessID;
        }
    } while (Process32Next(snapshot.get(), &processentry));
    
    // Process not found
    return 0;
}

/**
 * @brief Check if a handle is valid
 * 
 * @param handle Handle to check
 * @return true if handle is valid
 * @return false if handle is invalid
 */
bool is_handle_valid(HANDLE handle) {
    return (handle != nullptr && handle != INVALID_HANDLE_VALUE);
}

/**
 * @brief Get the last Windows error as a string
 * 
 * @return std::string Error message
 */
std::string get_last_error_as_string() {
    DWORD error_code = GetLastError();
    if (error_code == 0) {
        return "No error";
    }
    
    LPSTR message_buffer = nullptr;
    size_t size = FormatMessageA(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
        nullptr,
        error_code,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        reinterpret_cast<LPSTR>(&message_buffer),
        0,
        nullptr
    );
    
    // Create a unique_ptr with custom deleter for automatic cleanup
    std::unique_ptr<char, std::function<void(char*)>> message(
        message_buffer, 
        [](char* p) { if (p) LocalFree(p); }
    );
    
    if (size == 0) {
        return "Unknown error";
    }
    
    std::string error_message(message.get(), size);
    
    // Remove trailing newlines and carriage returns
    while (!error_message.empty() && 
           (error_message.back() == '\n' || error_message.back() == '\r')) {
        error_message.pop_back();
    }
    
    return "(" + std::to_string(error_code) + ") " + error_message;
}

} // namespace win_utils
