#pragma once

#include <string>
#include <vector>
#include <memory>
#include <Windows.h>

namespace process_killer {
    /**
     * @brief Converts a wide string to lowercase for case-insensitive comparison
     * 
     * @param str Input wide string
     * @return std::wstring Lowercase version of the input string
     */
    std::wstring to_lowercase(const std::wstring& str);
    
    /**
     * @brief Checks if a process name is in the target list
     * 
     * @param name Process name to check
     * @return true if the process is a target
     * @return false if the process is not a target
     */
    bool is_a_target(const std::wstring& name);
    
    /**
     * @brief Terminates all processes that match target criteria
     * 
     * @return void
     */
    void kill_target_processes();
    
    /**
     * @brief Gets the list of target process names
     * 
     * @return const std::vector<std::wstring>& Reference to the target process list
     */
    const std::vector<std::wstring>& get_target_list();
}
