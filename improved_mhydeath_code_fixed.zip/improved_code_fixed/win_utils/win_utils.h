#pragma once

#include <string>
#include <vector>
#include <Windows.h>
#include <TlHelp32.h>

namespace win_utils {
    /**
     * @brief Find a process ID by its name
     * 
     * @param process_name Name of the process to find
     * @return DWORD Process ID if found, 0 if not found
     */
    DWORD find_process_id(const std::wstring& process_name);
    
    /**
     * @brief Check if a handle is valid
     * 
     * @param handle Handle to check
     * @return true if handle is valid
     * @return false if handle is invalid
     */
    bool is_handle_valid(HANDLE handle);
    
    /**
     * @brief Get the last Windows error as a string
     * 
     * @return std::string Error message
     */
    std::string get_last_error_as_string();
    
    /**
     * @brief Create a safe handle with automatic cleanup
     * 
     * @tparam HandleType Type of the handle
     * @tparam CloseFunc Type of the close function
     * @param handle Handle to wrap
     * @param close_func Function to close the handle
     * @return std::unique_ptr with custom deleter for the handle
     */
    template<typename HandleType, typename CloseFunc>
    auto create_safe_handle(HandleType handle, CloseFunc close_func) {
        return std::unique_ptr<typename std::remove_pointer<HandleType>::type, CloseFunc>(handle, close_func);
    }
}
