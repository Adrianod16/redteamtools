#pragma once

#include <string>
#include <memory>
#include <functional>
#include <Windows.h>

namespace mhyprotect {
    /**
     * @brief Initialize the protection system
     * 
     * @return true if initialization was successful
     * @return false if initialization failed
     */
    bool init();
    
    /**
     * @brief Unload and clean up the protection system
     * 
     * @return void
     */
    void unload();
    
    /**
     * @brief Clean previous instances of the protection system
     * 
     * @return void
     */
    void clean();
    
    /**
     * @brief Driver implementation namespace
     */
    namespace driver_impl {
        /**
         * @brief Initialize the driver
         * 
         * @return true if initialization was successful
         * @return false if initialization failed
         */
        bool driver_init();
        
        /**
         * @brief Terminate a process by its ID
         * 
         * @param process_id Process ID to terminate
         * @return true if process was terminated successfully
         * @return false if termination failed
         */
        bool terminate_process(DWORD process_id);
    }
}
