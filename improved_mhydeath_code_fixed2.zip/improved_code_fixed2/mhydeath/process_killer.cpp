#include "process_killer.h"
#include <algorithm>
#include <iostream>
#include <memory>
#include <TlHelp32.h>
#include <cctype> // For towlower
#include "../mhyprotect/mhyprotect.h"

namespace process_killer {

// List of target process names to terminate
const std::vector<std::wstring> target_processes = {
    L"MhyRunner.exe",
    L"MhyProtect.exe",
    L"MhyService.exe"
    // Add other target processes as needed
};

/**
 * @brief Converts a wide string to lowercase for case-insensitive comparison
 * 
 * @param str Input wide string
 * @return std::wstring Lowercase version of the input string
 */
std::wstring to_lowercase(const std::wstring& str) {
    std::wstring result = str;
    std::transform(result.begin(), result.end(), result.begin(),
                  [](wchar_t c) { return towlower(c); }); // Using C towlower, not std::
    return result;
}

/**
 * @brief Checks if a process name is in the target list
 * 
 * @param name Process name to check
 * @return true if the process is a target
 * @return false if the process is not a target
 */
bool is_a_target(const std::wstring& name) {
    auto name_lower = to_lowercase(name);
    
    for (const auto& target : target_processes) {
        if (to_lowercase(target).compare(name_lower) == 0) {
            return true;
        }
    }
    
    return false;
}

/**
 * @brief Terminates all processes that match target criteria
 * 
 * @return void
 */
void kill_target_processes() {
    // Create snapshot of processes
    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    
    if (!hSnap || hSnap == INVALID_HANDLE_VALUE) {
        std::cerr << "[!] Failed to create process snapshot: " 
                  << GetLastError() << std::endl;
        return;
    }
    
    // Use RAII to ensure handle is closed
    std::unique_ptr<void, void(*)(HANDLE)> snapHandle(
        hSnap,
        [](HANDLE h) { if (h && h != INVALID_HANDLE_VALUE) CloseHandle(h); }
    );
    
    PROCESSENTRY32 processEntry = { sizeof(PROCESSENTRY32) };
    
    // Get first process
    if (!Process32First(snapHandle.get(), &processEntry)) {
        std::cerr << "[!] Failed to get first process: " 
                  << GetLastError() << std::endl;
        return;
    }
    
    // Iterate through all processes
    do {
        std::wstring exeName = processEntry.szExeFile;
        
        // Check if this process is a target
        if (is_a_target(exeName)) {
            std::wcout << L"[*] Found target process: " << exeName 
                      << L" (PID: " << processEntry.th32ProcessID << L")" << std::endl;
            
            // Attempt to terminate the process
            if (mhyprotect::driver_impl::terminate_process(processEntry.th32ProcessID)) {
                std::wcout << L"[+] Successfully terminated process: " 
                          << exeName << std::endl;
            } else {
                std::wcerr << L"[!] Failed to terminate process: " 
                          << exeName << std::endl;
            }
        }
    } while (Process32Next(snapHandle.get(), &processEntry));
}

/**
 * @brief Gets the list of target process names
 * 
 * @return const std::vector<std::wstring>& Reference to the target process list
 */
const std::vector<std::wstring>& get_target_list() {
    return target_processes;
}

} // namespace process_killer
