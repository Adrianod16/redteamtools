#pragma once

#include <string>
#include <vector>
#include <Windows.h>
#include <TlHelp32.h>

namespace win_utils {
    /**
     * @brief Find a process ID by its name
     * 
     * @param process_name Name of the process to find
     * @return DWORD Process ID if found, 0 if not found
     */
    DWORD find_process_id(const std::wstring& process_name);
    
    /**
     * @brief Check if a handle is valid
     * 
     * @param handle Handle to check
     * @return true if handle is valid
     * @return false if handle is invalid
     */
    bool is_handle_valid(HANDLE handle);
    
    /**
     * @brief Get the last Windows error as a string
     * 
     * @return std::string Error message
     */
    std::string get_last_error_as_string();
    
    /**
     * @brief Create a safe handle with automatic cleanup
     * 
     * @param handle Handle to wrap
     * @param close_func Function to close the handle
     * @return std::unique_ptr with custom deleter for the handle
     */
    template<typename HandleType>
    std::unique_ptr<void, void(*)(HANDLE)> create_safe_handle(HandleType handle) {
        return std::unique_ptr<void, void(*)(HANDLE)>(handle, 
            [](HANDLE h) { 
                if (h && h != INVALID_HANDLE_VALUE) 
                    CloseHandle(h); 
            }
        );
    }
}
